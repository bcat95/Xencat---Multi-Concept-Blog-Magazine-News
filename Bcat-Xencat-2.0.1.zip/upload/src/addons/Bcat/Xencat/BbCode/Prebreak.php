<?php

namespace Bcat\Xencat\BbCode;

use XF\BbCode\Renderer\AbstractRenderer;

class Prebreak
{
    public static function bbcode($tagChildren, $tagOption, $tag, array $options, $renderer)
    {
		return '';
	}
}
